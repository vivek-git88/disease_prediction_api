from flask import Flask, request, jsonify
import joblib
import numpy as np
from flask_cors import CORS
app = Flask(__name__)

# Load saved model
model = joblib.load("disease_model.pkl")
label_encoder = joblib.load("label_encoder.pkl")

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json

    # Extract features in SAME order as training
    features = [
        data["age"],
        data["difficulty_breathing"],
        data["cough"],
        data["fatigue"],
        data["fever"],
        data["headache"],
        data["nausea"]
    ]

    features = np.array(features).reshape(1, -1)

    prediction = model.predict(features)
    disease = label_encoder.inverse_transform(prediction)

    return jsonify({
        "predicted_disease": disease[0]
    })

if __name__ == "__main__":
    app.run(debug=True)
CORS(app) 
